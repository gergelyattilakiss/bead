class InvalidArchive(Exception):
    """Not a valid bead archive"""


class BoxError(Exception):
    """Box operation related error"""
